# [pp2d](https://discord.gg/zqXWgsH)

Plug & Play 2D (unofficial) wrapper for Citro3D. 

## License

pp2d is licensed under the MIT License.

## Changes

* depth parameter (Ryuzaki-MrL)
* standalone pp2d_free_texture (LiquidFenrir)
* 3d support (Robz8)
* load png from memory (ErmanSayin)
* Part Scale, Blend and combos (Manurocker95)
